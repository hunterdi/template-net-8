﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.StaticFiles;

namespace FileDemo70.Controllers
{
    
    [ApiController]
    public class TestController : ControllerBase
    {

        [HttpPost]
        [Route("PostComment")]
        public async Task<IActionResult> PostComment(UserCommentModel model)
        {
            if (model != null) { return Ok("Success"); }
            else { return BadRequest(); }
        }
    }

    public class UserCommentModel
    {
        public string Name { get; set; }
        public string Email { get; set; }
        public string Phone { get; set; }
        public string Message { get; set; }
    }
}
